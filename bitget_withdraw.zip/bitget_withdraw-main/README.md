## Bitget withdraw SOFT


### описание
софт выводит любые активы с BItGet на указанные адреса в `recipients.txt`

---

### настройка

1. указать свои адреса в `recipients.txt`
2. в `main.py` на строках 21-26 указать API и сделать остальные настройки под себя

---

### запуск

1. установить необходимые либы `pip install -r requirements.txt`
2. запустить софт `py main.py`

---

[🍭 kAramelniy 🍭](https://t.me/kAramelniy)
