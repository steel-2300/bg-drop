from random import uniform, randint, shuffle
from datetime import datetime
from time import sleep, time
from loguru import logger
from ccxt import bitget
from json import loads
from tqdm import tqdm
import sys
sys.__stdout__ = sys.stdout # error with `import inquirer` without this string in some system
from inquirer import prompt, List

from ccxt.base.errors import PermissionDenied


logger.remove()
logger.add(sys.stderr, format="<white>{time:HH:mm:ss}</white> | <level>{message}</level>")


 # SETTINGS #   # SETTINGS #   # SETTINGS #   # SETTINGS #   # SETTINGS #    # SETTINGS #    # SETTINGS #
                                                                                                        #
BITGET_KEY       = ""                                                                                   #
BITGET_SECRET    = ""                                                                                   #
BITGET_PASSWORD  = ""                                                                                   #
SHUFFLE         = True      # True - перемешивать колешельки | False - не перемешивать                  #
SLEEP_AFTER_ACC = [10, 20]  # задержка между акками от 10 до 20 секунд                                  #
RETRIES         = 3         # количество повторений при ошибках                                         #
                                                                                                        #
 # SETTINGS #   # SETTINGS #   # SETTINGS #   # SETTINGS #   # SETTINGS #    # SETTINGS #    # SETTINGS #

class IDEError(Exception): pass

def sleeping(*timing):
    if type(timing[0]) == list: timing = timing[0]
    if len(timing) == 2: x = randint(timing[0], timing[1])
    else: x = timing[0]
    desc = datetime.now().strftime('%H:%M:%S')
    for _ in tqdm(range(x), desc=desc, bar_format='{desc} | [•] Sleeping {n_fmt}/{total_fmt}'):
        sleep(1)


def bitget_withdraw(
        account: bitget,
        address: str,
        chain: str,
        token: str,
        withdraw_range: list,
        lowercase: bool = False,
        retry: int = 0
):
    try:

        to_withdraw = round(uniform(*withdraw_range), randint(4, 6))

        result = account.withdraw(
            code=token,
            amount=to_withdraw,
            address=address,
            params={"chain": chain}
        )
        if result.get('id'):
            logger.success(f'[+] Bitget | Success withdraw {to_withdraw} {token} to {address}')
            return to_withdraw

    except Exception as error:
        if 'Withdraw address is not in addressBook' in str(error) and lowercase is False:
            return bitget_withdraw(
                account=account,
                address=address,
                chain=chain,
                token=token,
                withdraw_range=withdraw_range,
                lowercase=True,
                retry=retry,
            )

        else:
            logger.error(f'[-] Bitget | Withdraw error: {error}')
            if retry + 1 < RETRIES:
                return bitget_withdraw(
                    account=account,
                    address=address,
                    chain=chain,
                    token=token,
                    withdraw_range=withdraw_range,
                    lowercase=True,
                    retry=retry + 1,
                )

            else:
                return 0


def get_token_chain(account: bitget):
    logger.debug(f'Enter which token you want to withdraw:')
    token = input('')
    resp = account.fetch_deposit_withdraw_fee(token)
    if resp is None:
        if token == token.upper():
            additional_error = ""
        else:
            additional_error = f'. Did you mean "{token.upper()}"?'
        logger.error(f'[-] Bitget | No token "{token}" found{additional_error}\n')
        return get_token_chain(account)

    chains = {chain["chain"]: {"fee": float(chain["withdrawFee"])} for chain in resp["info"]["chains"]}
    max_chain_len = max([len(chain) for chain in chains])
    for chain in chains:
        chains[chain]["spaces"] = " " * (max_chain_len - len(chain) + 2)
        if chains[chain]["fee"] == int(chains[chain]["fee"]): chains[chain]["fee"] = int(chains[chain]["fee"])

    try:
        if not sys.stdin.isatty(): # if IDE dont supports key pressing
            raise IDEError

        chains_list = [f'{chain}{chains[chain]["spaces"]}| fee {chains[chain]["fee"]} {token}' for chain in chains]
        questions = [
            List('prefered_chain', message="Choose chain to withdraw",
                 choices=chains_list)]
        chain = prompt(
            questions,

            raise_keyboard_interrupt=True
        )["prefered_chain"].split('  ')[0]

    except IDEError:
        chains_str = "\n".join(f'• {chain}{chains[chain]["spaces"]}| fee {chains[chain]["fee"]} {token}' for chain in chains)
        while True:
            logger.debug(f'Chains for {token}:\n{chains_str}\n\nEnter chain to withdraw:')
            chain = input('')
            if chain not in chains:
                logger.error(f'[-] Bitget | No chain "{chain}" found for "{token}"\n')
            else:
                break

    return {"chain": chain, "token": token}

def get_withdraw_amount():
    logger.opt(colors=True).debug(f'Enter <u>minimal</u> amount:')
    min_amount = float(input(''))
    logger.opt(colors=True).debug(f'Enter <u>max</u> amount:')
    max_amount = float(input(''))
    if min_amount > max_amount:
        logger.error(f'[-] Bitget | Invalid amounts! Max amount {max_amount} less than min amount {min_amount}\n')
        return get_withdraw_amount()
    return [min_amount, max_amount]


if __name__ == '__main__':
    with open('recipients.txt') as f: recipients = f.read().splitlines()
    if SHUFFLE: shuffle(recipients)
    logger.info(f'[•] Bitget | Going to withdraw to {len(recipients)} addresses!')

    account_bitget = bitget({
        'apiKey': BITGET_KEY,
        'secret': BITGET_SECRET,
        'password': BITGET_PASSWORD,
        'enableRateLimit': True,
        'options': {'defaultType': 'spot'},
    })
    try:
        coin_data = get_token_chain(account_bitget)
        amounts = get_withdraw_amount()
        logger.info(
            f'[•] Bitget | Starting! Max spent for all accounts is '
            f'{round(amounts[1] * len(recipients), 5)} {coin_data["token"]}\n'
        )

        total_spent = 0
        while recipients:
            address = recipients.pop(0)
            token_spend = bitget_withdraw(
                account=account_bitget,
                address=address,
                withdraw_range=amounts,
                **coin_data,
            )
            total_spent += token_spend

            if recipients: sleeping(SLEEP_AFTER_ACC)

        logger.success(f'All accounts are funded! Total spent: {round(total_spent, 5)} {coin_data["token"]}')

    except PermissionDenied as err:
        error_json = loads(str(err).removeprefix("bitget "))
        logger.error(f'[-] Bitget | {error_json["retMsg"]}')

    except KeyboardInterrupt as err:
        logger.info(f'[•] Soft | Exit')

    sleep(0.1)
    input(f'\n\n> Exit ')
